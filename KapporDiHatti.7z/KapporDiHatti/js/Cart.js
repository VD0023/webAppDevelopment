var removeCartItemButton = document.getElementsByClassName('btn-clear')
console.log(removeCartItemButton)
for (var i = 0; i < removeCartItemButton.length; i++) {
	var button = removeCartItemButton[i]
	button.addEventListener('click', function(event) {
		var buttonClicked = event.target
		buttonClicked.parentElement.parentElement.remove()
	})
}